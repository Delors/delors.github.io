package messaging.business;

import messaging.MessagingClient;
import messaging.model.Message;
import messaging.model.MessageSerializer;
import messaging.model.MessageType;

import java.util.*;
import java.util.concurrent.*;

/**
 * A minimal Customer that places orders with a Marketplace and prints outcomes.
 */
public class Customer {

    private final String customerId;
    private final String targetMarketplace;
    private final MessagingClient client;
    private final List<OrderResult> results = new CopyOnWriteArrayList<>();
    private final CountDownLatch resultLatch;

    /**
     * @param customerId       unique customer identifier
     * @param targetMarketplace the marketplace clientId to send orders to
     * @param client           the messaging client to use
     * @param expectedOrders   number of order results to wait for
     */
    public Customer(String customerId, String targetMarketplace, MessagingClient client, int expectedOrders) {
        this.customerId = customerId;
        this.targetMarketplace = targetMarketplace;
        this.client = client;
        this.resultLatch = new CountDownLatch(expectedOrders);
    }

    /**
     * Connect and start listening for order results.
     */
    public void start(String serverAddress) {
        client.connect(serverAddress, customerId);

        client.subscribe(customerId, (topic, messageId, jsonPayload) -> {
            try {
                Message msg = MessageSerializer.fromJson(jsonPayload);
                switch (msg.type()) {
                    case ORDER_SUCCESS -> {
                        String orderId = (String) msg.payload().get("orderId");
                        System.out.println("[CUSTOMER " + customerId + "] Order " + orderId + " SUCCEEDED!");
                        results.add(new OrderResult(orderId, true, null));
                        resultLatch.countDown();
                    }
                    case ORDER_FAILED -> {
                        String orderId = (String) msg.payload().get("orderId");
                        String reason = (String) msg.payload().get("reason");
                        System.out.println("[CUSTOMER " + customerId + "] Order " + orderId + " FAILED: " + reason);
                        results.add(new OrderResult(orderId, false, reason));
                        resultLatch.countDown();
                    }
                    default -> System.out.println("[CUSTOMER " + customerId + "] Ignoring: " + msg.type());
                }
            } catch (Exception e) {
                System.err.println("[CUSTOMER " + customerId + "] Error: " + e.getMessage());
            }
        });

        System.out.println("[CUSTOMER " + customerId + "] Started, targeting " + targetMarketplace);
    }

    /**
     * Place an order with the target marketplace.
     *
     * @param orderId unique order identifier
     * @param items   list of items, each a map with keys: sellerId, productId, quantity
     */
    public void placeOrder(String orderId, List<Map<String, Object>> items) {
        Message order = Message.create(customerId, targetMarketplace, MessageType.PLACE_ORDER,
            Map.of("orderId", orderId, "items", items));
        String json = MessageSerializer.toJson(order);
        client.send(targetMarketplace, order.messageId(), json);
        System.out.println("[CUSTOMER " + customerId + "] Placed order " + orderId);
    }

    /**
     * Wait for all expected order results.
     *
     * @param timeoutMs maximum time to wait
     * @return true if all results received within timeout
     */
    public boolean awaitResults(long timeoutMs) throws InterruptedException {
        return resultLatch.await(timeoutMs, TimeUnit.MILLISECONDS);
    }

    public List<OrderResult> getResults() {
        return Collections.unmodifiableList(results);
    }

    public void stop() {
        client.disconnect();
    }

    /**
     * Result of a placed order.
     */
    public record OrderResult(String orderId, boolean success, String reason) {}
}
