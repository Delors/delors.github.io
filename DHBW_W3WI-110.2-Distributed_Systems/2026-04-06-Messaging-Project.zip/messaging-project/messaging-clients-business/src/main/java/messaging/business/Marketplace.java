package messaging.business;

import java.util.*;
import java.util.concurrent.*;
import messaging.MessagingClient;
import messaging.model.Message;
import messaging.model.MessageSerializer;
import messaging.model.MessageType;

/**
 * Marketplace that receives orders from customers and orchestrates SAGA transactions
 * across multiple sellers. Uses the orchestration pattern.
 *
 * <p>SAGA Orchestration: The Marketplace acts as the central coordinator.
 * For each order, it sends RESERVE requests to all relevant sellers, waits for
 * responses, and either confirms success or triggers compensating CANCEL actions.
 */
public class Marketplace {

    private final String marketplaceId;
    private final MessagingClient client;
    private final long sagaTimeoutMs;

    // sagaId -> SagaState
    private final ConcurrentHashMap<String, SagaState> activeSagas =
        new ConcurrentHashMap<>();

    /**
     * @param marketplaceId  unique marketplace identifier (e.g., "marketplace-1")
     * @param client         the messaging client to use
     * @param sagaTimeoutMs  maximum time to wait for all seller responses
     */
    public Marketplace(
        String marketplaceId,
        MessagingClient client,
        long sagaTimeoutMs
    ) {
        this.marketplaceId = marketplaceId;
        this.client = client;
        this.sagaTimeoutMs = sagaTimeoutMs;
    }

    /**
     * Connect to the server and start listening for orders and seller responses.
     */
    public void start(String serverAddress) {
        client.connect(serverAddress, marketplaceId);

        client.subscribe(marketplaceId, (topic, messageId, jsonPayload) -> {
            try {
                Message msg = MessageSerializer.fromJson(jsonPayload);
                switch (msg.type()) {
                    case PLACE_ORDER -> handlePlaceOrder(msg);
                    case RESERVED -> handleReserved(msg);
                    case OUT_OF_STOCK -> handleOutOfStock(msg);
                    case CANCELLED -> handleCancelled(msg);
                    default -> System.out.println(
                        "[MARKETPLACE " + marketplaceId + "] Ignoring: " + msg.type()
                    );
                }
            } catch (Exception e) {
                System.err.println(
                    "[MARKETPLACE " + marketplaceId + "] Error: " + e.getMessage()
                );
                e.printStackTrace();
            }
        });

        System.out.println("[MARKETPLACE " + marketplaceId + "] Started");
    }

    private void handlePlaceOrder(Message msg) {
        String orderId = (String) msg.payload().get("orderId");
        String customerId = msg.senderId();
        String sagaId = UUID.randomUUID().toString();

        // Parse items from payload
        Object itemsObj = msg.payload().get("items");
        List<Map<String, Object>> items = parseItems(itemsObj);

        if (items.isEmpty()) {
            sendOrderResult(
                customerId,
                orderId,
                MessageType.ORDER_FAILED,
                "No items in order"
            );
            return;
        }

        SagaState saga = new SagaState(sagaId, orderId, customerId, items);
        activeSagas.put(sagaId, saga);

        System.out.println(
            "[MARKETPLACE " +
                marketplaceId +
                "] Starting SAGA " +
                sagaId +
                " for order " +
                orderId +
                " with " +
                items.size() +
                " items"
        );

        // Send RESERVE to each seller
        for (Map<String, Object> item : items) {
            String sellerId = (String) item.get("sellerId");
            String productId = (String) item.get("productId");
            Object qtyObj = item.get("quantity");
            int quantity =
                qtyObj instanceof Number n
                    ? n.intValue()
                    : Integer.parseInt(qtyObj.toString());

            Message reserve = Message.create(
                marketplaceId,
                sellerId,
                MessageType.RESERVE,
                Map.of(
                    "sagaId",
                    sagaId,
                    "orderId",
                    orderId,
                    "productId",
                    productId,
                    "quantity",
                    quantity
                )
            );
            client.send(
                sellerId,
                reserve.messageId(),
                MessageSerializer.toJson(reserve)
            );
        }

        // Start timeout watcher
        Thread.ofVirtual()
            .name("saga-timeout-" + sagaId)
            .start(() -> {
                try {
                    Thread.sleep(sagaTimeoutMs);
                    SagaState s = activeSagas.get(sagaId);
                    if (s != null && !s.isCompleted()) {
                        System.out.println(
                            "[MARKETPLACE " +
                                marketplaceId +
                                "] SAGA " +
                                sagaId +
                                " timed out"
                        );
                        s.markFailed("Timeout waiting for seller responses");
                        compensateAndNotify(s);
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseItems(Object itemsObj) {
        if (itemsObj instanceof List<?> list) {
            List<Map<String, Object>> result = new ArrayList<>();
            for (Object item : list) {
                if (item instanceof Map<?, ?> map) {
                    result.add((Map<String, Object>) map);
                }
            }
            return result;
        }
        if (itemsObj instanceof String s) {
            s = s.trim();
            if (s.startsWith("[")) {
                return parseJsonItemArray(s);
            }
        }
        return List.of();
    }

    /**
     * Manually parse a JSON array of item objects.
     * Each item is expected to have: sellerId, productId, quantity.
     */
    private List<Map<String, Object>> parseJsonItemArray(String jsonArray) {
        List<Map<String, Object>> result = new ArrayList<>();
        // Remove outer brackets
        String inner = jsonArray.substring(1, jsonArray.length() - 1).trim();
        if (inner.isEmpty()) return result;

        // Split by top-level commas (not inside braces)
        List<String> objectStrings = new ArrayList<>();
        int depth = 0;
        int start = 0;
        for (int i = 0; i < inner.length(); i++) {
            char c = inner.charAt(i);
            if (c == '{') depth++;
            else if (c == '}') depth--;
            else if (c == ',' && depth == 0) {
                objectStrings.add(inner.substring(start, i).trim());
                start = i + 1;
            }
        }
        objectStrings.add(inner.substring(start).trim());

        for (String objStr : objectStrings) {
            if (!objStr.startsWith("{")) continue;
            // Parse each item object using MessageSerializer by wrapping in a dummy message
            try {
                String dummyJson =
                    "{\"messageId\":\"\",\"senderId\":\"\",\"topic\":\"\",\"type\":\"PLACE_ORDER\",\"payload\":" +
                    objStr +
                    "}";
                Message parsed = MessageSerializer.fromJson(dummyJson);
                if (parsed.payload() != null) {
                    result.add(new HashMap<>(parsed.payload()));
                }
            } catch (Exception e) {
                System.err.println(
                    "[MARKETPLACE] Failed to parse item: " +
                        objStr +
                        " — " +
                        e.getMessage()
                );
            }
        }
        return result;
    }

    private void handleReserved(Message msg) {
        String sagaId = (String) msg.payload().get("sagaId");
        String productId = (String) msg.payload().get("productId");
        SagaState saga = activeSagas.get(sagaId);
        if (saga == null || saga.isCompleted()) return;

        saga.markItemReserved(productId, msg.senderId());
        System.out.println(
            "[MARKETPLACE " +
                marketplaceId +
                "] RESERVED " +
                productId +
                " in SAGA " +
                sagaId
        );

        if (saga.allItemsResolved()) {
            if (saga.allReserved()) {
                saga.markSucceeded();
                activeSagas.remove(sagaId);
                sendOrderResult(
                    saga.customerId,
                    saga.orderId,
                    MessageType.ORDER_SUCCESS,
                    null
                );
                System.out.println(
                    "[MARKETPLACE " + marketplaceId + "] SAGA " + sagaId + " SUCCESS"
                );
            } else {
                saga.markFailed("Some items out of stock");
                compensateAndNotify(saga);
            }
        }
    }

    private void handleOutOfStock(Message msg) {
        String sagaId = (String) msg.payload().get("sagaId");
        String productId = (String) msg.payload().get("productId");
        SagaState saga = activeSagas.get(sagaId);
        if (saga == null || saga.isCompleted()) return;

        saga.markItemFailed(productId, msg.senderId());
        System.out.println(
            "[MARKETPLACE " +
                marketplaceId +
                "] OUT_OF_STOCK " +
                productId +
                " in SAGA " +
                sagaId
        );

        if (saga.allItemsResolved()) {
            saga.markFailed("Item " + productId + " out of stock");
            compensateAndNotify(saga);
        }
    }

    private void handleCancelled(Message msg) {
        String sagaId = (String) msg.payload().get("sagaId");
        String productId = (String) msg.payload().get("productId");
        SagaState saga = activeSagas.get(sagaId);
        if (saga == null) return;

        saga.markCancellationConfirmed(productId);
        System.out.println(
            "[MARKETPLACE " +
                marketplaceId +
                "] CANCELLED confirmed for " +
                productId +
                " in SAGA " +
                sagaId
        );
    }

    private void compensateAndNotify(SagaState saga) {
        // Send CANCEL for all reserved items
        for (SagaState.ItemState item : saga.getReservedItems()) {
            Message cancel = Message.create(
                marketplaceId,
                item.sellerId(),
                MessageType.CANCEL,
                Map.of(
                    "sagaId",
                    saga.sagaId,
                    "orderId",
                    saga.orderId,
                    "productId",
                    item.productId(),
                    "quantity",
                    item.quantity()
                )
            );
            client.send(
                item.sellerId(),
                cancel.messageId(),
                MessageSerializer.toJson(cancel)
            );
        }

        activeSagas.remove(saga.sagaId);
        String reason =
            saga.failureReason != null
                ? saga.failureReason
                : "Order could not be fulfilled";
        sendOrderResult(saga.customerId, saga.orderId, MessageType.ORDER_FAILED, reason);
        System.out.println(
            "[MARKETPLACE " +
                marketplaceId +
                "] SAGA " +
                saga.sagaId +
                " FAILED: " +
                reason
        );
    }

    private void sendOrderResult(
        String customerId,
        String orderId,
        MessageType type,
        String reason
    ) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("orderId", orderId);
        if (reason != null) {
            payload.put("reason", reason);
        }
        Message result = Message.create(marketplaceId, customerId, type, payload);
        client.send(customerId, result.messageId(), MessageSerializer.toJson(result));
    }

    public void stop() {
        client.disconnect();
    }

    /**
     * Internal state tracking for a SAGA transaction.
     */
    static class SagaState {

        final String sagaId;
        final String orderId;
        final String customerId;
        final List<ItemState> items;
        volatile boolean completed = false;
        volatile boolean succeeded = false;
        volatile String failureReason;

        SagaState(
            String sagaId,
            String orderId,
            String customerId,
            List<Map<String, Object>> itemMaps
        ) {
            this.sagaId = sagaId;
            this.orderId = orderId;
            this.customerId = customerId;
            this.items = new CopyOnWriteArrayList<>();
            for (Map<String, Object> map : itemMaps) {
                String sellerId = (String) map.get("sellerId");
                String productId = (String) map.get("productId");
                Object qtyObj = map.get("quantity");
                int quantity =
                    qtyObj instanceof Number n
                        ? n.intValue()
                        : Integer.parseInt(qtyObj.toString());
                items.add(new ItemState(sellerId, productId, quantity));
            }
        }

        synchronized void markItemReserved(String productId, String sellerId) {
            for (ItemState item : items) {
                if (
                    item.productId().equals(productId) &&
                    item.sellerId().equals(sellerId)
                ) {
                    item.status = ItemStatus.RESERVED;
                    return;
                }
            }
        }

        synchronized void markItemFailed(String productId, String sellerId) {
            for (ItemState item : items) {
                if (
                    item.productId().equals(productId) &&
                    item.sellerId().equals(sellerId)
                ) {
                    item.status = ItemStatus.FAILED;
                    return;
                }
            }
        }

        synchronized void markCancellationConfirmed(String productId) {
            for (ItemState item : items) {
                if (
                    item.productId().equals(productId) &&
                    item.status == ItemStatus.CANCELLING
                ) {
                    item.status = ItemStatus.CANCELLED;
                    return;
                }
            }
        }

        synchronized boolean allItemsResolved() {
            return items
                .stream()
                .allMatch(
                    i -> i.status == ItemStatus.RESERVED || i.status == ItemStatus.FAILED
                );
        }

        synchronized boolean allReserved() {
            return items.stream().allMatch(i -> i.status == ItemStatus.RESERVED);
        }

        synchronized List<ItemState> getReservedItems() {
            List<ItemState> reserved = new ArrayList<>();
            for (ItemState item : items) {
                if (item.status == ItemStatus.RESERVED) {
                    item.status = ItemStatus.CANCELLING;
                    reserved.add(item);
                }
            }
            return reserved;
        }

        synchronized boolean isCompleted() {
            return completed;
        }

        synchronized void markSucceeded() {
            this.completed = true;
            this.succeeded = true;
        }

        synchronized void markFailed(String reason) {
            if (completed) return;
            this.completed = true;
            this.succeeded = false;
            this.failureReason = reason;
        }

        static class ItemState {

            private final String sellerId;
            private final String productId;
            private final int quantity;
            volatile ItemStatus status = ItemStatus.PENDING;

            ItemState(String sellerId, String productId, int quantity) {
                this.sellerId = sellerId;
                this.productId = productId;
                this.quantity = quantity;
            }

            String sellerId() {
                return sellerId;
            }

            String productId() {
                return productId;
            }

            int quantity() {
                return quantity;
            }
        }

        enum ItemStatus {
            PENDING,
            RESERVED,
            FAILED,
            CANCELLING,
            CANCELLED,
        }
    }
}
