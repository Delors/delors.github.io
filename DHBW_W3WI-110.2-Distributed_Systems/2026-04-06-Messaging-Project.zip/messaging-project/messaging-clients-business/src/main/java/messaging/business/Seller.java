package messaging.business;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import messaging.MessagingClient;
import messaging.model.Message;
import messaging.model.MessageSerializer;
import messaging.model.MessageType;

/**
 * A Seller that listens for RESERVE and CANCEL requests, manages in-memory stock,
 * and responds with RESERVED, OUT_OF_STOCK, or CANCELLED.
 * Stock is automatically restocked at a configured interval.
 */
public class Seller {

    private final String sellerId;
    private final MessagingClient client;
    private final ConcurrentHashMap<String, Integer> stock = new ConcurrentHashMap<>();
    private final int restockQuantity;
    private final long restockIntervalMs;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread restockThread;

    /**
     * @param sellerId         unique seller identifier (e.g., "seller-1")
     * @param client           the messaging client to use
     * @param products         list of product IDs this seller handles
     * @param initialStock     initial stock per product
     * @param restockQuantity  how many units to restock per interval
     * @param restockIntervalMs interval between restocks in milliseconds
     */
    public Seller(
        String sellerId,
        MessagingClient client,
        List<String> products,
        int initialStock,
        int restockQuantity,
        long restockIntervalMs
    ) {
        this.sellerId = sellerId;
        this.client = client;
        this.restockQuantity = restockQuantity;
        this.restockIntervalMs = restockIntervalMs;
        for (String product : products) {
            stock.put(product, initialStock);
        }
    }

    /**
     * Connect to the server and start listening for requests.
     */
    public void start(String serverAddress) {
        client.connect(serverAddress, sellerId);
        running.set(true);

        // Subscribe to messages addressed to this seller
        client.subscribe(sellerId, (topic, messageId, jsonPayload) -> {
            try {
                Message msg = MessageSerializer.fromJson(jsonPayload);
                switch (msg.type()) {
                    case RESERVE -> handleReserve(msg);
                    case CANCEL -> handleCancel(msg);
                    default -> System.out.println(
                        "[SELLER " + sellerId + "] Ignoring message type: " + msg.type()
                    );
                }
            } catch (Exception e) {
                System.err.println("[SELLER " + sellerId + "] Error: " + e.getMessage());
            }
        });

        // Start restock thread
        restockThread = Thread.ofVirtual()
            .name("seller-restock-" + sellerId)
            .start(this::restockLoop);
        System.out.println("[SELLER " + sellerId + "] Started with stock: " + stock);
    }

    private void handleReserve(Message msg) {
        String sagaId = (String) msg.payload().get("sagaId");
        String orderId = (String) msg.payload().get("orderId");
        String productId = (String) msg.payload().get("productId");
        Object qtyObj = msg.payload().get("quantity");
        int quantity =
            qtyObj instanceof Number n
                ? n.intValue()
                : Integer.parseInt(qtyObj.toString());

        String senderId = msg.senderId(); // marketplace

        if (!stock.containsKey(productId)) {
            sendResponse(senderId, sagaId, orderId, productId, MessageType.OUT_OF_STOCK);
            return;
        }

        boolean success = tryReserve(productId, quantity);
        if (success) {
            sendResponse(senderId, sagaId, orderId, productId, MessageType.RESERVED);
        } else {
            sendResponse(senderId, sagaId, orderId, productId, MessageType.OUT_OF_STOCK);
        }
    }

    private synchronized boolean tryReserve(String productId, int quantity) {
        Integer current = stock.get(productId);
        if (current == null || current < quantity) {
            return false;
        }
        stock.put(productId, current - quantity);
        System.out.println(
            "[SELLER " +
                sellerId +
                "] Reserved " +
                quantity +
                " of " +
                productId +
                ", remaining: " +
                stock.get(productId)
        );
        return true;
    }

    private void handleCancel(Message msg) {
        String sagaId = (String) msg.payload().get("sagaId");
        String orderId = (String) msg.payload().get("orderId");
        String productId = (String) msg.payload().get("productId");
        Object qtyObj = msg.payload().get("quantity");
        int quantity =
            qtyObj instanceof Number n
                ? n.intValue()
                : Integer.parseInt(qtyObj.toString());

        String senderId = msg.senderId(); // marketplace

        // Restore stock
        stock.merge(productId, quantity, Integer::sum);
        System.out.println(
            "[SELLER " +
                sellerId +
                "] Cancelled reservation of " +
                quantity +
                " of " +
                productId +
                ", restored to: " +
                stock.get(productId)
        );

        sendResponse(senderId, sagaId, orderId, productId, MessageType.CANCELLED);
    }

    private void sendResponse(
        String recipientId,
        String sagaId,
        String orderId,
        String productId,
        MessageType type
    ) {
        Message response = Message.create(
            sellerId,
            recipientId,
            type,
            Map.of("sagaId", sagaId, "orderId", orderId, "productId", productId)
        );
        String json = MessageSerializer.toJson(response);
        client.send(recipientId, response.messageId(), json);
    }

    private void restockLoop() {
        while (running.get() && !Thread.currentThread().isInterrupted()) {
            try {
                Thread.sleep(restockIntervalMs);
                for (String product : stock.keySet()) {
                    stock.merge(product, restockQuantity, Integer::sum);
                }
                System.out.println(
                    "[SELLER " + sellerId + "] Restocked. Current stock: " + stock
                );
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    public void stop() {
        running.set(false);
        if (restockThread != null) {
            restockThread.interrupt();
        }
        client.disconnect();
    }

    public Map<String, Integer> getStock() {
        return Collections.unmodifiableMap(stock);
    }
}
