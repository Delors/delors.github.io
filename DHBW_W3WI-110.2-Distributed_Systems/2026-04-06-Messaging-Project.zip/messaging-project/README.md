# Reliable Messaging Server with SAGA Transactions

## 1. Overview

In this project you will implement a **reliable messaging server** and **client library** that enable distributed business transactions using the SAGA pattern.

### Business Scenario

A **Customer** places an order for multiple products with a **Marketplace**. The Marketplace contacts one or more **Sellers** to reserve and ship each product. The Marketplace must guarantee that the customer receives either **all** ordered products, or **none** at all (no partial fulfilment). The overall process is only allowed to take a maximum allowed time, after that the business process is considered to have failed. In case of a failure ensure that all reserved products are 

All parties communicate exclusively through a central **Messaging Server** using a **Messaging Client API**. The server is a generic broker — it has no knowledge of orders, SAGAs, or business logic.

### System Components

```text
┌──────────┐         ┌──────────────────┐         ┌──────────┐
│ Customer │◄───────►│                  │◄───────►│ Seller 1 │
└──────────┘         │                  │         └──────────┘
                     │  Messaging       │         ┌──────────┐
┌──────────────┐     │  Server          │◄───────►│ Seller 2 │
│ Marketplace 1│◄───►│  (ZeroMQ         │         └──────────┘
└──────────────┘     │   ROUTER)        │         ┌──────────┐
┌──────────────┐     │                  │◄───────►│ Seller 3 │
│ Marketplace 2│◄───►│                  │         └──────────┘
└──────────────┘     └──────────────────┘              ...
```

All components use **ZeroMQ DEALER/ROUTER** sockets and **Java Virtual Threads**.

---

## 2. Your Task

You must implement **two classes**:

| Class | Module | Description |
|-------|--------|-------------|
| `messaging.StudentMessagingServer` | `messaging-server/` | A generic, stateless message broker |
| `messaging.StudentMessagingClient` | `messaging-client/` | A thin client-side library wrapping ZeroMQ |

Both classes already exist as stubs with detailed Javadoc and TODO comments. Your job is to replace the `throw new UnsupportedOperationException(...)` calls with working implementations.

**Do not modify** any other modules (`messaging-api`, `messaging-clients-business`, `messaging-chaos`, `messaging-tests-public`). They are read-only.

---

## 3. Protocol Specification

### 3.1 Message Envelope

All messages are **plain JSON strings** transmitted as ZeroMQ frames. Every message has this envelope:

```json
{
  "messageId": "<UUID v4>",
  "senderId":  "<clientId>",
  "topic":     "<recipientClientId or broadcast topic>",
  "type":      "<MESSAGE_TYPE>",
  "payload":   { /* type-specific fields */ }
}
```

- `messageId` is globally unique, assigned by the sender, and used for exactly-once deduplication on the server.
- `senderId` is the `clientId` of the sending client.
- `topic` is the `clientId` of the intended recipient.
- `type` is one of the message types listed below.
- `payload` contains type-specific fields as key-value pairs.

### 3.2 Message Types

#### Customer → Marketplace

| Type | Payload Fields |
|------|---------------|
| `PLACE_ORDER` | `orderId: String`, `items: [{sellerId, productId, quantity}]` |

#### Marketplace → Seller

| Type | Payload Fields |
|------|---------------|
| `RESERVE` | `sagaId: String`, `orderId: String`, `productId: String`, `quantity: int` |
| `CANCEL`  | `sagaId: String`, `orderId: String`, `productId: String`, `quantity: int` |

#### Seller → Marketplace

| Type | Payload Fields |
|------|---------------|
| `RESERVED`     | `sagaId: String`, `orderId: String`, `productId: String` |
| `OUT_OF_STOCK` | `sagaId: String`, `orderId: String`, `productId: String` |
| `CANCELLED`    | `sagaId: String`, `orderId: String`, `productId: String` |

#### Marketplace → Customer

| Type | Payload Fields |
|------|---------------|
| `ORDER_SUCCESS` | `orderId: String` |
| `ORDER_FAILED`  | `orderId: String`, `reason: String` |

#### Infrastructure (client ↔ server) — handled by the API layer, not visible to application code

| Type | Direction | Description |
|------|-----------|-------------|
| `CONNECT`    | client → server | Register clientId with the server |
| `ACK`        | server → client | Acknowledge receipt of a message |
| `HEARTBEAT`  | client → server | Keep-alive ping |
| `DISCONNECT` | client → server | Clean shutdown |

---

## 4. API Contract

### `MessagingServer` Interface

```java
public interface MessagingServer {
    /**
     * Start the server and bind to the given port.
     * @throws IllegalStateException if already started
     */
    void start(int port);

    /**
     * Gracefully shut down: stop accepting new connections, flush pending
     * messages, release all resources.
     */
    void stop();

    /** Return the number of clients currently connected. */
    int getConnectedClientCount();

    /** Return the total number of messages forwarded since start. */
    long getTotalMessagesForwarded();
}
```

**Implementation requirements:**
- Use a **ZeroMQ ROUTER** socket to accept connections.
- Use **Java Virtual Threads** (`Thread.ofVirtual()`) — one virtual thread per connected client or per incoming message.
- All public methods must be **thread-safe**.

### `MessagingClient` Interface

```java
public interface MessagingClient {
    void connect(String serverAddress, String clientId);
    void send(String topic, String messageId, String jsonPayload);
    void subscribe(String topic, MessageHandler handler);
    void disconnect();

    @FunctionalInterface
    interface MessageHandler {
        void onMessage(String topic, String messageId, String jsonPayload);
    }
}
```

**Implementation requirements:**
- Use a **ZeroMQ DEALER** socket with the identity set to `clientId`.
- `send()` blocks until the server ACKs. Retries on timeout (configurable).
- `subscribe()` handlers are invoked concurrently in virtual threads.
- Send periodic heartbeats so the server can detect disconnections.

---

## 5. Exactly-Once Semantics

Your server **must guarantee** that each message with a unique `messageId` is forwarded to the recipient **exactly once**, even if the sender retransmits.

### How it works

1. The **client** retransmits on timeout until it receives an `ACK` from the server.
2. The **server** maintains a `Set<String>` of already-forwarded `messageId`s per recipient.
3. If the server receives a duplicate `messageId` for the same recipient, it **drops** the message silently but still **ACKs** the sender (so the sender stops retrying).

### Delivery to offline recipients

- If the recipient is not currently connected, the server **queues** the message in memory.
- When the recipient reconnects, all queued messages are flushed.
- Queue depth per recipient is bounded by `server.maxQueueDepth`. If the queue is full, messages are dropped with a warning log.

### ACK semantics

- The server sends an `ACK` as soon as it has either:
  - (a) forwarded the message to a connected recipient, or
  - (b) enqueued it for an offline recipient.
- The ACK carries the original `messageId`.

---

## 6. Configuration

All components read settings from `config.properties` (classpath or `-Dconfig.path=...`).

| Property | Default | Description |
|----------|---------|-------------|
| `server.port` | `5555` | Port the server binds to |
| `server.maxQueueDepth` | `1000` | Max queued messages per offline recipient |
| `client.ackTimeoutMs` | `500` | How long the client waits for an ACK before retrying |
| `client.maxRetries` | `10` | Maximum number of send retries |
| `saga.timeoutMs` | `30000` | Maximum time for a SAGA to complete |
| `seller.restock.intervalMs` | `10000` | Interval between automatic restocks |
| `seller.restock.quantity` | `5` | Units added per restock cycle |
| `marketplace.ids` | `1,2` | Comma-separated marketplace instance IDs |
| `marketplace.{id}.clientId` | — | Client ID for each marketplace |
| `seller.ids` | `1,2,3,4,5` | Comma-separated seller instance IDs |
| `seller.{id}.clientId` | — | Client ID for each seller |
| `seller.{id}.products` | — | Comma-separated product IDs |
| `seller.{id}.initialStock` | — | Initial stock per product |
| `customer.clientId` | `customer-1` | Customer client ID |
| `customer.targetMarketplace` | `marketplace-1` | Which marketplace to send orders to |

---

## 7. Running the System

### Prerequisites

- **Java 25** 
- **Maven 3.9+**

### Build the project

```bash
mvn clean compile
```

### Run the public tests

```bash
mvn test -pl messaging-tests-public
```

### Running components individually (for manual testing)

You can write a simple `main` method or use the provided business clients programmatically:

```java
// 1. Start the server
MessagingServer server = new StudentMessagingServer();
server.start(5555);

// 2. Start sellers
MessagingClient sellerClient = new StudentMessagingClient();
Seller seller = new Seller("seller-1", sellerClient,
    List.of("productA", "productB"), 3, 5, 10000);
seller.start("tcp://localhost:5555");

// 3. Start marketplace
MessagingClient mpClient = new StudentMessagingClient();
Marketplace marketplace = new Marketplace("marketplace-1", mpClient, 30000);
marketplace.start("tcp://localhost:5555");

// 4. Start customer and place order
MessagingClient custClient = new StudentMessagingClient();
Customer customer = new Customer("customer-1", "marketplace-1", custClient, 1);
customer.start("tcp://localhost:5555");
customer.placeOrder("order-1", List.of(
    Map.of("sellerId", "seller-1", "productId", "productA", "quantity", 1)
));
customer.awaitResults(30000);
```

---

## 8. Testing

### Public test suite (7 tests)

These tests are your primary development feedback loop:

| Test | What it checks |
|------|---------------|
| `testSingleMessageDelivery` | One sender, one receiver, message arrives exactly once |
| `testMultipleClients` | 5 concurrent senders, 1 receiver, all messages arrive |
| `testOfflineDelivery` | Sender sends while receiver offline; delivered on reconnect |
| `testOrderSuccessPath` | Full SAGA with 2 sellers, enough stock → `ORDER_SUCCESS` |
| `testOrderFailedPath` | SAGA with 1 seller out of stock → `ORDER_FAILED`, no stock leaked |
| `testDeduplication` | Same `messageId` sent twice; recipient receives exactly once |
| `testGracefulDisconnect` | Client disconnects; server decrements count |

Run them with:

```bash
mvn test -pl messaging-tests-public
```

> **Note:** The public tests currently use the reference implementation. When you're ready to test your own code, update the test to instantiate `StudentMessagingServer` and `StudentMessagingClient` instead of the reference classes.

### ChaosMessagingClient

The `ChaosMessagingClient` in `messaging-chaos/` is a test utility that wraps any `MessagingClient` and randomly drops or delays outgoing messages. Use it to stress-test your retry and exactly-once logic:

```java
MessagingClient realClient = new StudentMessagingClient();
MessagingClient chaosClient = new ChaosMessagingClient(realClient, 0.3, 200);
// 30% drop rate, up to 200ms random delay
```

---

## 9. Submission

Package your two implementation classes as a JAR:

```bash
mvn package -pl messaging-server,messaging-client
```

Submit the resulting JAR files:
- `messaging-server/target/messaging-server-1.0.0-SNAPSHOT.jar`
- `messaging-client/target/messaging-client-1.0.0-SNAPSHOT.jar`


### Grading validation

Your submission will be loaded via reflection:

```java
Class<?> serverClass = Class.forName("messaging.StudentMessagingServer");
MessagingServer server = (MessagingServer) serverClass.getDeclaredConstructor().newInstance();

Class<?> clientClass = Class.forName("messaging.StudentMessagingClient");
MessagingClient client = (MessagingClient) clientClass.getDeclaredConstructor().newInstance();
```

Make sure your classes:
- Are in the `messaging` package
- Have a public no-argument constructor
- Implement the respective interfaces

---

## 10. Code Comprehension & Oral Exam

Your submission will be evaluated in a **mandatory oral exam** (approximately 15 minutes per group). During the exam you will be asked to:

- **Explain** how your server and client work, starting from any method the examiner chooses
- **Trace** the path of a message through your system, from `send()` to handler invocation
- **Answer** "what if" questions about concurrency, failure, and edge cases in your code
- **Modify** a small part of your implementation live (e.g., add a feature, fix a planted bug)

Both group members are expected to be able to explain any part of the submission. 

> **AI tool usage:** You are welcome to use AI-assisted coding tools during development. However, you must fully understand every line of your submitted code. The oral exam is specifically designed to verify this — inability to explain your own code will result in a failing grade for the project.

---

## 11. Grading Criteria

| Category | Weight | Details |
|----------|--------|---------|
| **Public tests** | 20% | All 7 public tests must pass |
| **Private tests** | 30% | Exhaustive tests covering chaos, concurrency, edge cases, load |
| **Oral exam** | 50% | (see above)) |

### Private test categories (for reference)

- Exactly-once under simulated network failures (30% drop rate)
- Duplicate deduplication from concurrent senders
- Offline queue overflow handling
- Concurrent SAGAs across multiple marketplaces and sellers
- Stock integrity after many concurrent orders
- SAGA timeout when seller is unresponsive
- Partial failure with compensating transactions
- Heavy load (500 msg/s for 10 seconds)
- Reconnect storms (50 simultaneous reconnects)
- Client crash mid-SAGA
- Large message delivery (1 MB payload)

---

## 12. Constraints and Non-Requirements

- The server does **not** need to survive its own crash (no persistent storage).
- Sellers and Marketplaces use **in-memory** state only — no database.
- No authentication or TLS is required.
- The server must handle **≥ 50 concurrent clients** without degradation.
- The Marketplace, Seller, and Customer are provided as complete, read-only reference clients. You do **not** need to implement any business logic — only the messaging infrastructure.
- **Allowed libraries:** ZeroMQ (`jeromq`), JUnit 5, Mockito, JaCoCo — nothing else.

---

## Project Structure

```
messaging-project/
├── pom.xml                          Parent POM (multi-module)
├── config.properties                Configuration for all components
├── README.md                        This file
│
├── messaging-api/                   Interfaces & shared model (READ-ONLY)
│   └── src/main/java/messaging/
│       ├── MessagingServer.java
│       ├── MessagingClient.java
│       └── model/
│           ├── Message.java
│           ├── MessageType.java
│           └── MessageSerializer.java
│
├── messaging-server/                ★ YOUR IMPLEMENTATION ★
│   └── src/main/java/messaging/
│       └── StudentMessagingServer.java
│
├── messaging-client/                ★ YOUR IMPLEMENTATION ★
│   └── src/main/java/messaging/
│       └── StudentMessagingClient.java
│
├── messaging-clients-business/      Business clients (READ-ONLY)
│   └── src/main/java/messaging/business/
│       ├── Marketplace.java
│       ├── Seller.java
│       └── Customer.java
│
├── messaging-chaos/                 Test utility (READ-ONLY)
│   └── src/main/java/messaging/chaos/
│       └── ChaosMessagingClient.java
│
└── messaging-tests-public/          Public test suite
    └── src/test/java/messaging/tests/publicsuite/
        └── PublicServerTest.java
```

Good luck!
