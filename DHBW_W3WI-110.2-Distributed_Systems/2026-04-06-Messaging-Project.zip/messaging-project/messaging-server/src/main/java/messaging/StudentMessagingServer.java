package messaging;

/**
 * Student implementation of {@link MessagingServer}.
 *
 * <h2>Requirements</h2>
 * <ul>
 *   <li>Use a ZeroMQ ROUTER socket to accept client connections.</li>
 *   <li>Use Java Virtual Threads ({@code Thread.ofVirtual()}) — one virtual thread per connected client.</li>
 *   <li>Route messages from any sender to any named recipient (topic-based addressing).</li>
 *   <li>Provide exactly-once delivery: maintain a set of already-forwarded messageIds per recipient.
 *       Duplicates are silently dropped but still ACKed to the sender.</li>
 *   <li>Queue messages for offline recipients (in memory). Max queue depth is configurable
 *       via {@code server.maxQueueDepth} in {@code config.properties}.</li>
 *   <li>Handle infrastructure messages: CONNECT, HEARTBEAT, DISCONNECT.</li>
 *   <li>All public methods must be thread-safe.</li>
 * </ul>
 *
 * @see MessagingServer
 */
public class StudentMessagingServer implements MessagingServer {

    // TODO: Declare fields for ZContext, ROUTER socket, connected clients map,
    //       deduplication sets, offline queues, counters, etc.

    @Override
    public void start(int port) {
        // TODO: Create ZContext and ROUTER socket
        // TODO: Bind to tcp://*:{port}
        // TODO: Load config.properties for maxQueueDepth
        // TODO: Start listener thread (virtual thread) that:
        //   - Receives ZMsg from ROUTER socket
        //   - Extracts identity frame and data frame
        //   - Spawns a virtual thread to process each message
        //   - Dispatches based on message type:
        //     * CONNECT   → register client, send ACK, flush offline queue
        //     * DISCONNECT → unregister client
        //     * HEARTBEAT → update client identity, send ACK
        //     * Other     → forward to recipient (with dedup), send ACK to sender
        throw new UnsupportedOperationException("TODO: implement start()");
    }

    @Override
    public void stop() {
        // TODO: Set running flag to false
        // TODO: Interrupt and join listener thread
        // TODO: Close ZContext
        // TODO: Clear all state
        throw new UnsupportedOperationException("TODO: implement stop()");
    }

    @Override
    public int getConnectedClientCount() {
        // TODO: Return size of connected clients map
        throw new UnsupportedOperationException("TODO: implement getConnectedClientCount()");
    }

    @Override
    public long getTotalMessagesForwarded() {
        // TODO: Return the total forwarded count (use AtomicLong)
        throw new UnsupportedOperationException("TODO: implement getTotalMessagesForwarded()");
    }
}
