package messaging.chaos;

import messaging.MessagingClient;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A decorator that wraps any {@link MessagingClient} and simulates network failures
 * by randomly dropping or delaying outgoing messages.
 *
 * <p>Used exclusively in tests to exercise retry / exactly-once logic.
 */
public class ChaosMessagingClient implements MessagingClient {

    private final MessagingClient delegate;
    private final double dropRate;
    private final long maxDelayMs;

    /**
     * @param delegate   the real client to wrap
     * @param dropRate   probability [0.0, 1.0] that an outgoing message is silently dropped
     * @param maxDelayMs maximum random delay (ms) added before sending; 0 means no delay
     */
    public ChaosMessagingClient(MessagingClient delegate, double dropRate, long maxDelayMs) {
        this.delegate = delegate;
        this.dropRate = dropRate;
        this.maxDelayMs = maxDelayMs;
    }

    @Override
    public void connect(String serverAddress, String clientId) {
        delegate.connect(serverAddress, clientId);
    }

    @Override
    public void send(String topic, String messageId, String jsonPayload) {
        // Randomly drop
        if (ThreadLocalRandom.current().nextDouble() < dropRate) {
            System.out.println("[CHAOS] Dropped message " + messageId);
            return;
        }
        // Randomly delay
        if (maxDelayMs > 0) {
            long delay = ThreadLocalRandom.current().nextLong(maxDelayMs);
            if (delay > 0) {
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
        }
        delegate.send(topic, messageId, jsonPayload);
    }

    @Override
    public void subscribe(String topic, MessageHandler handler) {
        delegate.subscribe(topic, handler);
    }

    @Override
    public void disconnect() {
        delegate.disconnect();
    }
}
