package messaging.tests.publicsuite;

import messaging.MessagingClient;
import messaging.MessagingServer;
import messaging.StudentMessagingClient;
import messaging.StudentMessagingServer;
import messaging.business.Customer;
import messaging.business.Marketplace;
import messaging.business.Seller;
import messaging.model.Message;
import messaging.model.MessageSerializer;
import messaging.model.MessageType;

import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Public test suite.
 * Tests the messaging server and client with basic happy-path scenarios.
 */
class PublicServerTest {

    private MessagingServer server;
    private int port;
    private final List<MessagingClient> clients = new CopyOnWriteArrayList<>();

    @BeforeEach
    void setUp() throws IOException {
        port = findFreePort();
        server = new StudentMessagingServer();
        server.start(port);
    }

    @AfterEach
    void tearDown() {
        for (MessagingClient c : clients) {
            try { c.disconnect(); } catch (Exception ignored) {}
        }
        clients.clear();
        server.stop();
    }

    private String serverAddress() {
        return "tcp://localhost:" + port;
    }

    private MessagingClient createClient() {
        MessagingClient c = new StudentMessagingClient();
        clients.add(c);
        return c;
    }

    private static int findFreePort() throws IOException {
        try (ServerSocket socket = new ServerSocket(0)) {
            return socket.getLocalPort();
        }
    }

    @Test
    @DisplayName("Single message delivery: one sender, one receiver, message arrives exactly once")
    void testSingleMessageDelivery() throws Exception {
        MessagingClient sender = createClient();
        MessagingClient receiver = createClient();

        sender.connect(serverAddress(), "sender-1");
        receiver.connect(serverAddress(), "receiver-1");

        CountDownLatch latch = new CountDownLatch(1);
        List<String> received = new CopyOnWriteArrayList<>();

        receiver.subscribe("receiver-1", (topic, messageId, jsonPayload) -> {
            received.add(messageId);
            latch.countDown();
        });

        // Allow subscriptions to settle
        Thread.sleep(200);

        String msgId = UUID.randomUUID().toString();
        Message msg = new Message(msgId, "sender-1", "receiver-1", MessageType.PLACE_ORDER,
            Map.of("orderId", "order-1", "items", List.of()));
        sender.send("receiver-1", msgId, MessageSerializer.toJson(msg));

        assertTrue(latch.await(5, TimeUnit.SECONDS), "Message should be received within 5 seconds");
        assertEquals(1, received.size(), "Should receive exactly one message");
    }

    @Test
    @DisplayName("Multiple clients: 5 senders, 1 receiver, all messages arrive")
    void testMultipleClients() throws Exception {
        MessagingClient receiver = createClient();
        receiver.connect(serverAddress(), "multi-receiver");

        int senderCount = 5;
        CountDownLatch latch = new CountDownLatch(senderCount);
        Set<String> receivedIds = ConcurrentHashMap.newKeySet();

        receiver.subscribe("multi-receiver", (topic, messageId, jsonPayload) -> {
            receivedIds.add(messageId);
            latch.countDown();
        });

        Thread.sleep(200);

        for (int i = 0; i < senderCount; i++) {
            MessagingClient sender = createClient();
            sender.connect(serverAddress(), "sender-" + i);
            String msgId = UUID.randomUUID().toString();
            Message msg = new Message(msgId, "sender-" + i, "multi-receiver", MessageType.PLACE_ORDER,
                Map.of("orderId", "order-" + i, "items", List.of()));
            sender.send("multi-receiver", msgId, MessageSerializer.toJson(msg));
        }

        assertTrue(latch.await(10, TimeUnit.SECONDS), "All messages should arrive within 10 seconds");
        assertEquals(senderCount, receivedIds.size(), "Should receive all " + senderCount + " messages");
    }

    @Test
    @DisplayName("Offline delivery: message sent while receiver offline, delivered on reconnect")
    void testOfflineDelivery() throws Exception {
        MessagingClient sender = createClient();
        sender.connect(serverAddress(), "offline-sender");

        // Send message while receiver is offline
        String msgId = UUID.randomUUID().toString();
        Message msg = new Message(msgId, "offline-sender", "offline-receiver", MessageType.PLACE_ORDER,
            Map.of("orderId", "order-offline", "items", List.of()));
        sender.send("offline-receiver", msgId, MessageSerializer.toJson(msg));

        // Now connect the receiver
        Thread.sleep(500);
        MessagingClient receiver = createClient();
        CountDownLatch latch = new CountDownLatch(1);
        List<String> received = new CopyOnWriteArrayList<>();

        receiver.subscribe("offline-receiver", (topic, messageId, jsonPayload) -> {
            received.add(messageId);
            latch.countDown();
        });

        receiver.connect(serverAddress(), "offline-receiver");

        assertTrue(latch.await(5, TimeUnit.SECONDS), "Offline message should be delivered on reconnect");
        assertEquals(1, received.size());
    }

    @Test
    @DisplayName("Order success path: full SAGA with 2 sellers, enough stock")
    void testOrderSuccessPath() throws Exception {
        // Start sellers
        MessagingClient sellerClient1 = createClient();
        Seller seller1 = new Seller("test-seller-1", sellerClient1, List.of("productA"), 10, 5, 60000);
        seller1.start(serverAddress());

        MessagingClient sellerClient2 = createClient();
        Seller seller2 = new Seller("test-seller-2", sellerClient2, List.of("productB"), 10, 5, 60000);
        seller2.start(serverAddress());

        // Start marketplace
        MessagingClient mpClient = createClient();
        Marketplace marketplace = new Marketplace("test-marketplace", mpClient, 30000);
        marketplace.start(serverAddress());

        // Start customer
        MessagingClient custClient = createClient();
        Customer customer = new Customer("test-customer", "test-marketplace", custClient, 1);
        customer.start(serverAddress());

        Thread.sleep(500);

        // Place order
        customer.placeOrder("order-success-1", List.of(
            Map.of("sellerId", "test-seller-1", "productId", "productA", "quantity", 1),
            Map.of("sellerId", "test-seller-2", "productId", "productB", "quantity", 1)
        ));

        assertTrue(customer.awaitResults(15000), "Should receive order result");
        assertEquals(1, customer.getResults().size());
        assertTrue(customer.getResults().get(0).success(), "Order should succeed");

        seller1.stop();
        seller2.stop();
        marketplace.stop();
    }

    @Test
    @DisplayName("Order failed path: SAGA with seller out of stock")
    void testOrderFailedPath() throws Exception {
        // Start seller with zero stock
        MessagingClient sellerClient = createClient();
        Seller seller = new Seller("fail-seller", sellerClient, List.of("productX"), 0, 0, 600000);
        seller.start(serverAddress());

        // Start marketplace
        MessagingClient mpClient = createClient();
        Marketplace marketplace = new Marketplace("fail-marketplace", mpClient, 30000);
        marketplace.start(serverAddress());

        // Start customer
        MessagingClient custClient = createClient();
        Customer customer = new Customer("fail-customer", "fail-marketplace", custClient, 1);
        customer.start(serverAddress());

        Thread.sleep(500);

        // Place order for product with zero stock
        customer.placeOrder("order-fail-1", List.of(
            Map.of("sellerId", "fail-seller", "productId", "productX", "quantity", 1)
        ));

        assertTrue(customer.awaitResults(15000), "Should receive order result");
        assertEquals(1, customer.getResults().size());
        assertFalse(customer.getResults().get(0).success(), "Order should fail");

        seller.stop();
        marketplace.stop();
    }

    @Test
    @DisplayName("Deduplication: same messageId sent twice, recipient receives exactly once")
    void testDeduplication() throws Exception {
        MessagingClient sender = createClient();
        MessagingClient receiver = createClient();

        sender.connect(serverAddress(), "dedup-sender");
        receiver.connect(serverAddress(), "dedup-receiver");

        AtomicInteger count = new AtomicInteger(0);
        receiver.subscribe("dedup-receiver", (topic, messageId, jsonPayload) -> {
            count.incrementAndGet();
        });

        Thread.sleep(200);

        // Send same messageId twice
        String msgId = UUID.randomUUID().toString();
        Message msg = new Message(msgId, "dedup-sender", "dedup-receiver", MessageType.PLACE_ORDER,
            Map.of("orderId", "order-dedup", "items", List.of()));
        String json = MessageSerializer.toJson(msg);

        sender.send("dedup-receiver", msgId, json);
        sender.send("dedup-receiver", msgId, json);

        Thread.sleep(2000);
        assertEquals(1, count.get(), "Duplicate message should be delivered exactly once");
    }

    @Test
    @DisplayName("Graceful disconnect: client disconnects, server decrements count")
    void testGracefulDisconnect() throws Exception {
        MessagingClient client1 = createClient();
        MessagingClient client2 = createClient();

        client1.connect(serverAddress(), "disc-client-1");
        client2.connect(serverAddress(), "disc-client-2");

        Thread.sleep(500);
        assertEquals(2, server.getConnectedClientCount(), "Should have 2 connected clients");

        client1.disconnect();
        clients.remove(client1);
        Thread.sleep(500);

        assertEquals(1, server.getConnectedClientCount(), "Should have 1 connected client after disconnect");
    }
}
