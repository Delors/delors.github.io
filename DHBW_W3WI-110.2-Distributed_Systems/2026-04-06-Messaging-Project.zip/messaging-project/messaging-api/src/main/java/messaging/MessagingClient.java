package messaging;

/**
 * Client-side messaging API that sits between application code and raw ZeroMQ.
 */
public interface MessagingClient {

    /** Connect to the server and register under the given clientId. */
    void connect(String serverAddress, String clientId);

    /**
     * Send a message to the given topic (recipient clientId or broadcast topic).
     * Blocks until the server has acknowledged receipt (exactly-once guarantee).
     * @param topic      recipient clientId or broadcast topic
     * @param messageId  caller-assigned UUID; used for deduplication on the server
     * @param jsonPayload the JSON message body
     */
    void send(String topic, String messageId, String jsonPayload);

    /**
     * Register a handler for incoming messages on the given topic.
     * The handler is invoked in a virtual thread for each received message.
     */
    void subscribe(String topic, MessageHandler handler);

    /** Gracefully disconnect from the server. */
    void disconnect();

    @FunctionalInterface
    interface MessageHandler {
        void onMessage(String topic, String messageId, String jsonPayload);
    }
}
