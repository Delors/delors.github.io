package messaging.model;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Hand-rolled JSON serializer/deserializer for {@link Message}.
 *
 * <p>No external JSON libraries are used. This implementation handles the known
 * envelope structure: flat maps of String→Object where Object is one of
 * {@code String}, {@code Integer/Long}, {@code null}, or a raw JSON
 * string (for nested objects / arrays).
 */
public final class MessageSerializer {

    private MessageSerializer() {}

    // ──────────────────────────────────────────────────────────────────────
    //  Serialization
    // ──────────────────────────────────────────────────────────────────────

    /**
     * Serialize a {@link Message} to a valid JSON string.
     */
    public static String toJson(Message message) {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        appendJsonString(sb, "messageId");
        sb.append(':');
        appendJsonString(sb, message.messageId());
        sb.append(',');

        appendJsonString(sb, "senderId");
        sb.append(':');
        appendJsonString(sb, message.senderId());
        sb.append(',');

        appendJsonString(sb, "topic");
        sb.append(':');
        appendJsonString(sb, message.topic());
        sb.append(',');

        appendJsonString(sb, "type");
        sb.append(':');
        appendJsonString(sb, message.type().name());
        sb.append(',');

        appendJsonString(sb, "payload");
        sb.append(':');
        if (message.payload() == null) {
            sb.append("null");
        } else {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<String, Object> entry : message.payload().entrySet()) {
                if (!first) {
                    sb.append(',');
                }
                first = false;
                appendJsonString(sb, entry.getKey());
                sb.append(':');
                appendValue(sb, entry.getValue());
            }
            sb.append('}');
        }

        sb.append('}');
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void appendValue(StringBuilder sb, Object value) {
        if (value == null) {
            sb.append("null");
        } else if (value instanceof Number) {
            sb.append(value);
        } else if (value instanceof Boolean) {
            sb.append(value);
        } else if (value instanceof Map<?, ?> map) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                if (!first) sb.append(',');
                first = false;
                appendJsonString(sb, entry.getKey().toString());
                sb.append(':');
                appendValue(sb, entry.getValue());
            }
            sb.append('}');
        } else if (value instanceof Collection<?> collection) {
            sb.append('[');
            boolean first = true;
            for (Object item : collection) {
                if (!first) sb.append(',');
                first = false;
                appendValue(sb, item);
            }
            sb.append(']');
        } else {
            String s = value.toString();
            // If the value already looks like raw JSON (array or object), emit it verbatim
            if (s.startsWith("[") || s.startsWith("{")) {
                sb.append(s);
            } else {
                appendJsonString(sb, s);
            }
        }
    }

    private static void appendJsonString(StringBuilder sb, String value) {
        if (value == null) {
            sb.append("null");
            return;
        }
        sb.append('"');
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                default -> sb.append(c);
            }
        }
        sb.append('"');
    }

    // ──────────────────────────────────────────────────────────────────────
    //  Deserialization – minimal recursive-descent JSON parser
    // ──────────────────────────────────────────────────────────────────────

    /**
     * Deserialize a JSON string to a {@link Message}.
     */
    public static Message fromJson(String json) {
        Parser parser = new Parser(json);
        Map<String, Object> top = parser.parseObject();

        String messageId = asString(top.get("messageId"));
        String senderId = asString(top.get("senderId"));
        String topic = asString(top.get("topic"));
        MessageType type = MessageType.valueOf(asString(top.get("type")));

        Map<String, Object> payload = null;
        Object rawPayload = top.get("payload");
        if (rawPayload instanceof Map<?, ?> m) {
            @SuppressWarnings("unchecked")
            Map<String, Object> casted = (Map<String, Object>) m;
            payload = casted;
        }

        return new Message(messageId, senderId, topic, type, payload);
    }

    private static String asString(Object o) {
        return o == null ? null : o.toString();
    }

    // ──────────────────────────────────────────────────────────────────────
    //  Recursive-descent JSON parser
    // ──────────────────────────────────────────────────────────────────────

    private static final class Parser {

        private final String input;
        private int pos;

        Parser(String input) {
            this.input = input;
            this.pos = 0;
        }

        // ── helpers ──────────────────────────────────────────────────────

        private void skipWhitespace() {
            while (pos < input.length() && Character.isWhitespace(input.charAt(pos))) {
                pos++;
            }
        }

        private char peek() {
            skipWhitespace();
            if (pos >= input.length()) {
                throw new IllegalStateException("Unexpected end of JSON input");
            }
            return input.charAt(pos);
        }

        private char advance() {
            char c = peek();
            pos++;
            return c;
        }

        private void expect(char expected) {
            char c = advance();
            if (c != expected) {
                throw new IllegalStateException(
                    "Expected '" +
                        expected +
                        "' but got '" +
                        c +
                        "' at position " +
                        (pos - 1)
                );
            }
        }

        // ── value parsing ───────────────────────────────────────────────

        /**
         * Parse any JSON value and return it as a Java object.
         *
         * <ul>
         *   <li>JSON string  → {@code String}</li>
         *   <li>JSON number  → {@code Long} or {@code Double}</li>
         *   <li>JSON boolean → {@code Boolean}</li>
         *   <li>JSON null    → {@code null}</li>
         *   <li>JSON object  → {@code Map<String,Object>}</li>
         *   <li>JSON array   → raw JSON {@code String} (kept verbatim for payload)</li>
         * </ul>
         */
        Object parseValue() {
            skipWhitespace();
            char c = peek();
            return switch (c) {
                case '"' -> parseString();
                case '{' -> parseObject();
                case '[' -> parseRawStructure(); // store arrays as raw JSON
                case 't', 'f' -> parseBoolean();
                case 'n' -> parseNull();
                default -> parseNumber();
            };
        }

        /**
         * Parse a JSON value, but for nested objects and arrays return
         * the raw JSON string instead of a parsed structure.  Used for
         * payload values so that complex nested structures survive
         * round-tripping.
         */
        Object parsePayloadValue() {
            skipWhitespace();
            char c = peek();
            return switch (c) {
                case '"' -> parseString();
                case '{' -> parseRawStructure(); // nested objects as raw JSON
                case '[' -> parseRawStructure(); // arrays as raw JSON
                case 't', 'f' -> parseBoolean();
                case 'n' -> parseNull();
                default -> parseNumber();
            };
        }

        // ── strings ─────────────────────────────────────────────────────

        String parseString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (pos < input.length()) {
                char c = input.charAt(pos);
                pos++;
                if (c == '"') {
                    return sb.toString();
                }
                if (c == '\\') {
                    if (pos >= input.length()) {
                        throw new IllegalStateException(
                            "Unexpected end of string escape"
                        );
                    }
                    char escaped = input.charAt(pos);
                    pos++;
                    switch (escaped) {
                        case '"' -> sb.append('"');
                        case '\\' -> sb.append('\\');
                        case '/' -> sb.append('/');
                        case 'n' -> sb.append('\n');
                        case 'r' -> sb.append('\r');
                        case 't' -> sb.append('\t');
                        case 'b' -> sb.append('\b');
                        case 'f' -> sb.append('\f');
                        case 'u' -> {
                            if (pos + 4 > input.length()) {
                                throw new IllegalStateException(
                                    "Invalid unicode escape"
                                );
                            }
                            String hex = input.substring(pos, pos + 4);
                            sb.append((char) Integer.parseInt(hex, 16));
                            pos += 4;
                        }
                        default -> {
                            sb.append('\\');
                            sb.append(escaped);
                        }
                    }
                } else {
                    sb.append(c);
                }
            }
            throw new IllegalStateException("Unterminated string");
        }

        // ── objects ─────────────────────────────────────────────────────

        Map<String, Object> parseObject() {
            return parseObjectInternal(false);
        }

        private Map<String, Object> parseObjectInternal(boolean payloadLevel) {
            expect('{');
            Map<String, Object> map = new LinkedHashMap<>();
            skipWhitespace();
            if (peek() == '}') {
                pos++;
                return map;
            }
            while (true) {
                String key = parseString();
                expect(':');
                Object value;
                if (payloadLevel) {
                    value = parsePayloadValue();
                } else if ("payload".equals(key)) {
                    // The payload object: parse its keys with payloadValue semantics
                    skipWhitespace();
                    if (peek() == 'n') {
                        value = parseNull();
                    } else {
                        value = parseObjectInternal(true);
                    }
                } else {
                    value = parseValue();
                }
                map.put(key, value);
                skipWhitespace();
                char next = advance();
                if (next == '}') {
                    return map;
                }
                if (next != ',') {
                    throw new IllegalStateException(
                        "Expected ',' or '}' but got '" +
                            next +
                            "' at position " +
                            (pos - 1)
                    );
                }
            }
        }

        // ── raw structures (arrays / nested objects kept as strings) ────

        /**
         * Capture a complete JSON array or object as a raw string.
         * Respects nesting depth and quoted strings so that brackets
         * inside strings are not miscounted.
         */
        String parseRawStructure() {
            skipWhitespace();
            int start = pos;
            char open = input.charAt(pos);
            char close = (open == '[') ? ']' : '}';
            int depth = 0;
            boolean inString = false;
            while (pos < input.length()) {
                char c = input.charAt(pos);
                if (inString) {
                    if (c == '\\') {
                        pos++; // skip escaped char
                    } else if (c == '"') {
                        inString = false;
                    }
                } else {
                    if (c == '"') {
                        inString = true;
                    } else if (c == open) {
                        depth++;
                    } else if (c == close) {
                        depth--;
                        if (depth == 0) {
                            pos++;
                            return input.substring(start, pos);
                        }
                    }
                }
                pos++;
            }
            throw new IllegalStateException(
                "Unterminated JSON structure starting at position " + start
            );
        }

        // ── numbers ─────────────────────────────────────────────────────

        Object parseNumber() {
            skipWhitespace();
            int start = pos;
            boolean isFloat = false;
            if (pos < input.length() && input.charAt(pos) == '-') {
                pos++;
            }
            while (pos < input.length()) {
                char c = input.charAt(pos);
                if (Character.isDigit(c)) {
                    pos++;
                } else if (c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-') {
                    isFloat = true;
                    pos++;
                } else {
                    break;
                }
            }
            String numStr = input.substring(start, pos);
            if (numStr.isEmpty()) {
                throw new IllegalStateException("Expected number at position " + start);
            }
            if (isFloat) {
                return Double.parseDouble(numStr);
            }
            long val = Long.parseLong(numStr);
            if (val >= Integer.MIN_VALUE && val <= Integer.MAX_VALUE) {
                return (int) val;
            }
            return val;
        }

        // ── booleans ────────────────────────────────────────────────────

        Object parseBoolean() {
            skipWhitespace();
            if (input.startsWith("true", pos)) {
                pos += 4;
                return Boolean.TRUE;
            }
            if (input.startsWith("false", pos)) {
                pos += 5;
                return Boolean.FALSE;
            }
            throw new IllegalStateException("Expected boolean at position " + pos);
        }

        // ── null ────────────────────────────────────────────────────────

        Object parseNull() {
            skipWhitespace();
            if (input.startsWith("null", pos)) {
                pos += 4;
                return null;
            }
            throw new IllegalStateException("Expected null at position " + pos);
        }
    }
}
