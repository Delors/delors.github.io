package messaging.model;

import java.util.Map;
import java.util.UUID;

/**
 * Represents a protocol message. All messages are serialized as JSON.
 *
 * @param messageId  globally unique ID (UUID v4), assigned by sender
 * @param senderId   the clientId of the sender
 * @param topic      recipient clientId or broadcast topic
 * @param type       the message type
 * @param payload    type-specific fields as key-value pairs
 */
public record Message(
    String messageId,
    String senderId,
    String topic,
    MessageType type,
    Map<String, Object> payload
) {
    /**
     * Create a new Message with an auto-generated UUID.
     */
    public static Message create(String senderId, String topic, MessageType type, Map<String, Object> payload) {
        return new Message(UUID.randomUUID().toString(), senderId, topic, type, payload);
    }
}
