package messaging.model;

public enum MessageType {
    // Business messages
    PLACE_ORDER,
    RESERVE,
    CANCEL,
    RESERVED,
    OUT_OF_STOCK,
    CANCELLED,
    ORDER_SUCCESS,
    ORDER_FAILED,
    // Infrastructure messages
    CONNECT,
    ACK,
    HEARTBEAT,
    DISCONNECT
}
