package messaging;

/**
 * A generic message broker. Implementations must use ZeroMQ DEALER/ROUTER
 * sockets and Java Virtual Threads.
 *
 * <p>Thread safety: all public methods must be safe to call from multiple threads.
 */
public interface MessagingServer {

    /**
     * Start the server and bind to the given port.
     * @throws IllegalStateException if already started
     */
    void start(int port);

    /**
     * Gracefully shut down: stop accepting new connections, flush pending
     * messages, release all resources.
     */
    void stop();

    /**
     * Return the number of clients currently connected.
     */
    int getConnectedClientCount();

    /**
     * Return the total number of messages forwarded since start.
     */
    long getTotalMessagesForwarded();
}
