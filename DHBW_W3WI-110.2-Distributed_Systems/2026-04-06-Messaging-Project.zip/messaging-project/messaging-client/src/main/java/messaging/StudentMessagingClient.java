package messaging;

/**
 * Student implementation of {@link MessagingClient}.
 *
 * <h2>Requirements</h2>
 * <ul>
 *   <li>Use a ZeroMQ DEALER socket to communicate with the server.</li>
 *   <li>Set socket identity to the clientId so the server can route messages back.</li>
 *   <li>{@code connect()} sends a CONNECT message and starts a receiver virtual thread
 *       and a heartbeat virtual thread.</li>
 *   <li>{@code send()} blocks until an ACK is received from the server for the given messageId.
 *       Retries on timeout. Interval and max retries from config.properties:
 *       {@code client.ackTimeoutMs} (default 500), {@code client.maxRetries} (default 10).</li>
 *   <li>{@code subscribe()} registers a {@link MessageHandler} for a topic.
 *       Handlers are invoked in virtual threads.</li>
 *   <li>{@code disconnect()} sends DISCONNECT, stops threads, closes socket.</li>
 *   <li>The receiver thread polls for incoming messages, dispatches to handlers or completes ACK futures.</li>
 *   <li>The heartbeat thread sends HEARTBEAT messages at the configured interval.</li>
 * </ul>
 *
 * @see MessagingClient
 */
public class StudentMessagingClient implements MessagingClient {

    // TODO: Declare fields for ZContext, DEALER socket, clientId, connected flag,
    //       receiver/heartbeat threads, pending ACK futures, handler map, config values.

    @Override
    public void connect(String serverAddress, String clientId) {
        // TODO: Create ZContext and DEALER socket
        // TODO: Set socket identity to clientId bytes
        // TODO: Connect to serverAddress (e.g., "tcp://localhost:5555")
        // TODO: Start receiver virtual thread (polls for messages)
        // TODO: Start heartbeat virtual thread
        // TODO: Send CONNECT message and wait for ACK
        throw new UnsupportedOperationException("TODO: implement connect()");
    }

    @Override
    public void send(String topic, String messageId, String jsonPayload) {
        // TODO: Build a Message envelope with the provided messageId, topic, and payload
        // TODO: Register a CompletableFuture for this messageId
        // TODO: Retry loop: send, then wait for ACK with timeout
        // TODO: On success: return. On max retries exceeded: throw RuntimeException
        throw new UnsupportedOperationException("TODO: implement send()");
    }

    @Override
    public void subscribe(String topic, MessageHandler handler) {
        // TODO: Register the handler in a ConcurrentHashMap<String, MessageHandler>
        throw new UnsupportedOperationException("TODO: implement subscribe()");
    }

    @Override
    public void disconnect() {
        // TODO: Send DISCONNECT message
        // TODO: Stop heartbeat and receiver threads
        // TODO: Close ZContext
        // TODO: Fail all pending ACK futures
        throw new UnsupportedOperationException("TODO: implement disconnect()");
    }
}
